export interface AnalyzedImage {
  readonly tags: string[];
  readonly description: string;
  readonly categories: string[];
}
