export * from "./analyzed-image.model";
