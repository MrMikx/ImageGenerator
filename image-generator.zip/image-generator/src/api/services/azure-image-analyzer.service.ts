import { ComputerVisionClient } from "@azure/cognitiveservices-computervision";
import { CognitiveServicesCredentials } from "@azure/ms-rest-azure-js";
import { AnalyzedImage } from "../models";

export class AzureImageAnalyzerService {
  private static instance: AzureImageAnalyzerService;

  private readonly client: ComputerVisionClient;

  private constructor() {
    const endpoint = process.env.AZURE_COMPUTE_VISION_ENDPOINT as string;

    const key = process.env.AZURE_COMPUTE_VISION_KEY as string;

    const credentials = new CognitiveServicesCredentials(key);

    this.client = new ComputerVisionClient(credentials, endpoint);
  }

  public static getInstance(): AzureImageAnalyzerService {
    if (!AzureImageAnalyzerService.instance) {
      AzureImageAnalyzerService.instance = new AzureImageAnalyzerService();
    }
    return AzureImageAnalyzerService.instance;
  }

  public async analyzeImage(imageUrl: string): Promise<AnalyzedImage> {
    const response = await this.client.analyzeImage(imageUrl, {
      visualFeatures: ["Categories", "Description", "Tags"]
    });

    const tags = (response.tags || [])
      .map((tag) => tag.name)
      .filter(Boolean) as string[];

    const categories = (response.categories || [])
      .map((category) => category.name)
      .filter(Boolean) as string[];

    const description = (response.description?.captions || [])[0].text || "";

    return {
      tags,
      categories,
      description
    };
  }
}
