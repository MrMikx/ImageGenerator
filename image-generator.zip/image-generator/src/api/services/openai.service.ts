import { Configuration, OpenAIApi } from "openai";

export class OpenAIService {
  private static instance: OpenAIService;

  private readonly client: OpenAIApi;

  private constructor() {
    const configuration = new Configuration({
      apiKey: process.env.OPENAI_API_KEY
    });

    this.client = new OpenAIApi(configuration);
  }

  public static getInstance(): OpenAIService {
    if (!OpenAIService.instance) {
      OpenAIService.instance = new OpenAIService();
    }

    return OpenAIService.instance;
  }

  public async createImage(prompt: string): Promise<{
    imageUrl: string;
  }> {
    const { data } = await this.client.createImage({
      prompt,
      n: 1,
      size: "512x512"
    });

    return {
      imageUrl: data.data[0].url as string
    };
  }
}
