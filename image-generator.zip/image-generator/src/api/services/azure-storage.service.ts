import { StoredImageDto, StoredImageMetadata } from "@/common/models";
import { BlobServiceClient, ContainerClient } from "@azure/storage-blob";
import { randomUUID } from "crypto";
import { AnalyzedImage } from "../models";

export class AzureStorageService {
  private readonly IMAGES_CONTAINER_NAME = "images";

  private static instance: AzureStorageService;

  private readonly client: ContainerClient;

  public static getInstance(): AzureStorageService {
    if (!this.instance) {
      this.instance = new AzureStorageService();
    }
    return this.instance;
  }

  private constructor() {
    const connectionUrl = process.env.AZURE_STORAGE_CONNECTION_URL;

    if (!connectionUrl) {
      throw new Error("AZURE_STORAGE_CONNECTION_URL is not set");
    }

    this.client = BlobServiceClient.fromConnectionString(
      connectionUrl
    ).getContainerClient(this.IMAGES_CONTAINER_NAME);
  }

  public async uploadImage({
    imageUrl,
    userId,
    analyzedImage
  }: {
    imageUrl: string;
    userId: string;
    analyzedImage: AnalyzedImage;
  }) {
    const imageId = randomUUID();

    const blobName = this.createImageName(userId, imageId);

    const blockBlobClient = this.client.getBlockBlobClient(blobName);

    const imageResponse = await fetch(imageUrl);

    if (!imageResponse.ok || !imageResponse.body) {
      throw new Error("Failed to fetch image");
    }

    const imageBuffer = Buffer.from(await imageResponse.arrayBuffer());

    const metadata: StoredImageMetadata = {
      id: imageId,
      userId,
      categories: analyzedImage.categories.join(","),
      description: analyzedImage.description,
      tags: analyzedImage.tags.join(",")
    };

    await blockBlobClient.upload(imageBuffer, imageBuffer.length, {
      metadata: metadata as unknown as Record<string, string>
    });
  }

  public async getCurrentUserImages(userId: string): Promise<StoredImageDto[]> {
    const images: StoredImageDto[] = [];

    for await (const blob of this.client.listBlobsFlat({
      prefix: userId,
      includeMetadata: true
    })) {
      const { id, categories, description, tags } =
        blob.metadata as unknown as StoredImageMetadata;

      const url = this.client.getBlobClient(blob.name).url;

      images.push({
        id,
        imageUrl: url,
        createdAt: blob.properties.createdOn
          ? blob.properties.createdOn.toISOString()
          : new Date().toISOString(),
        categories: categories.split(","),
        description,
        tags: tags.split(",")
      });
    }

    return images;
  }

  public async removeImage(imageId: string, userId: string): Promise<void> {
    const blobName = this.createImageName(userId, imageId);

    await this.client.deleteBlob(blobName);
  }

  private createImageName(userId: string, imageId: string): string {
    return `${userId}-${imageId}.jpg`;
  }
}
