export enum QueryKeys {
  UserImages = "user-images"
}
