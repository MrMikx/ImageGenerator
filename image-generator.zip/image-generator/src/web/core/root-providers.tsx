"use client";

import {
  QueryCache,
  QueryClient,
  QueryClientProvider
} from "@tanstack/react-query";

import { WithChildrenProps } from "../ts";

interface Props extends WithChildrenProps {}

const client = new QueryClient({
  queryCache: new QueryCache()
});

export function RootProviders({ children }: Props): React.JSX.Element {
  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}
