import { ImagesApiService } from "@/common/services";
import { useQuery } from "@tanstack/react-query";
import { QueryKeys } from "../constants";

export function useUserImages() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: [QueryKeys.UserImages],
    queryFn: async () => ImagesApiService.getUserImages()
  });

  return {
    images: data || [],
    isLoading,
    error,
    refetch
  };
}
