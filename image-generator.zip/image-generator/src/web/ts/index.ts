export * from "./interfaces/generic-props.interface";
