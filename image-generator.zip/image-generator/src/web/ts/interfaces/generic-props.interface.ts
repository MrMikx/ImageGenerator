export interface WithChildrenProps {
  readonly children?: React.ReactNode;
}

export interface ParamProps<T> {
  readonly param: T;
}
