import { cn } from "../utils";

export function Navbar(): React.JSX.Element {
  return (
    <div className="mr-4 hidden md:flex">
      <nav className="flex items-center space-x-6 text-sm font-medium">
        <p>Image Generator</p>
      </nav>
    </div>
  );
}
