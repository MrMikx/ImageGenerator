import Image from "next/image";

import { TrashIcon, Loader2Icon } from "lucide-react";

import { AspectRatio } from "./ui/aspect-ratio";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "./ui/card";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ImagesApiService } from "@/common/services";
import { QueryKeys } from "../constants";

interface Props {
  readonly id: string;
  readonly imageUrl: string;
  readonly description: string;
  readonly tags: string[];
  readonly createdAt: string;
}

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export function ImageCard({
  id,
  imageUrl,
  createdAt,
  description,
  tags
}: Props) {
  const queryClient = useQueryClient();

  const { isLoading, mutate } = useMutation({
    mutationFn: async () =>
      ImagesApiService.deleteImage({
        imageId: id
      }),
    onSuccess: () => {
      queryClient.invalidateQueries([QueryKeys.UserImages]);
    }
  });

  const formattedDate = new Date(createdAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    minute: "numeric",
    hour: "numeric"
  });

  return isLoading ? (
    <div className="flex h-full w-full items-center justify-center p-8">
      <Loader2Icon className="h-8 w-8 animate-spin" />
    </div>
  ) : (
    <Card>
      <CardHeader>
        <CardTitle>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">{formattedDate}</span>
            <TrashIcon
              className="h-4 w-4 cursor-pointer transition-colors duration-200 hover:text-red-500"
              onClick={() => {
                mutate();
              }}
            />
          </div>
        </CardTitle>
        <CardDescription>
          <span className="text-sm text-gray-500">
            AI Description: {capitalize(description)}
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <AspectRatio className="bg-muted " ratio={4 / 3}>
          <Image
            src={imageUrl}
            alt="User image"
            className="rounded-lg object-cover"
            fill
          />
        </AspectRatio>
        <div className="flex flex-wrap gap-2">
          {tags.map(
            (tag) =>
              tag.length > 0 && (
                <span
                  key={tag}
                  className="rounded-full bg-gray-100 px-2 py-1 text-sm text-gray-500"
                >
                  {tag}
                </span>
              )
          )}
        </div>
      </CardContent>
    </Card>
  );
}
