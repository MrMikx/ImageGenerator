export function Footer() {
  return <></>;
}
