import { AzureStorageService } from "@/api/services";
import { auth } from "@clerk/nextjs";
import { NextResponse } from "next/server";

export async function GET() {
  const { userId } = auth();

  const azureStorage = AzureStorageService.getInstance();

  const userImages = await azureStorage.getCurrentUserImages(userId as string);

  return NextResponse.json(userImages);
}
