import { NextResponse } from "next/server";

import { isAxiosError } from "axios";

import { GenerateImageDto } from "@/common/models";
import {
  AzureImageAnalyzerService,
  AzureStorageService,
  OpenAIService
} from "@/api/services";
import { auth } from "@clerk/nextjs";

export async function POST(req: Request) {
  const { userId } = auth();

  const openAiService = OpenAIService.getInstance();
  const azureStorage = AzureStorageService.getInstance();
  const imageAnalyzerService = AzureImageAnalyzerService.getInstance();

  const imageDto = (await req.json()) as Awaited<GenerateImageDto>;

  try {
    const { imageUrl } = await openAiService.createImage(imageDto.text);

    const analyzedImage = await imageAnalyzerService.analyzeImage(imageUrl);

    await azureStorage.uploadImage({
      imageUrl,
      userId: userId as string,
      analyzedImage
    });

    return NextResponse.json({
      status: "success"
    });
  } catch (err) {
    if (isAxiosError(err)) {
      console.error(err.response?.data);
    } else {
      console.error(err);
    }

    return NextResponse.json({
      status: "error"
    });
  }
}
