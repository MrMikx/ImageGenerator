import { auth } from "@clerk/nextjs";
import { NextResponse } from "next/server";

import { AzureStorageService } from "@/api/services";

interface Params {
  params: {
    id: string;
  };
}

export async function DELETE(
  req: Request,
  { params: { id: imageId } }: Params
): Promise<NextResponse> {
  const { userId } = auth();

  const azureStorage = AzureStorageService.getInstance();

  await azureStorage.removeImage(imageId, userId as string);

  return NextResponse.json({
    status: "success"
  });
}
