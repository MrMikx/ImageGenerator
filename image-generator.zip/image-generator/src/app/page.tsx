"use client";

import React from "react";

import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { SendIcon, XIcon, Loader2 } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";

import { GenerateImageDto } from "@/common/models";

import { Button } from "@/web/components/ui/button";
import { Textarea } from "@/web/components/ui/textarea";

import * as z from "zod";
import { Form, FormField, FormItem } from "@/web/components/react-hook-form";
import { FormLabel } from "@/web/components/react-hook-form";
import { FormControl } from "@/web/components/react-hook-form";
import { FormDescription } from "@/web/components/react-hook-form";
import { FormMessage } from "@/web/components/react-hook-form";
import { ImageCard } from "@/web/components/image-card";
import { ImagesApiService } from "@/common/services";
import { useUserImages } from "@/web/hooks/use-user-images.hook";

const TEXT_AREA_MAX_LENGTH = 255;

const formSchema = z.object({
  description: z
    .string()
    .min(3, {
      message: "Description must be at least 3 characters"
    })
    .max(TEXT_AREA_MAX_LENGTH, {
      message: `Description must be between 3 and ${TEXT_AREA_MAX_LENGTH} characters`
    })
});

type FormValues = z.infer<typeof formSchema>;

export default function HomePage() {
  const { images, refetch } = useUserImages();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema)
  });

  function resetForm(): void {
    form.resetField("description", {
      defaultValue: ""
    });
  }

  const genImgMutation = useMutation({
    mutationFn: async (data: GenerateImageDto) =>
      ImagesApiService.sendGenerateImgRequest(data),
    onMutate: () => {
      resetForm();
    },
    onSuccess: () => {
      refetch();
    }
  });

  function handleSubmit(data: FormValues): void {
    genImgMutation.mutate({
      text: data.description
    });
  }

  return (
    <section className="container relative pb-10">
      <div className="w-fill mt-10 grid gap-8">
        <div className="flex-1 overflow-hidden rounded-lg border bg-background shadow-xl">
          <div className="grid w-full gap-1.5 p-10">
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(handleSubmit)}
                className=" space-y-6"
              >
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>
                          <span className="text-sm font-medium text-gray-900">
                            Description
                          </span>
                        </FormLabel>
                        <XIcon
                          className="h-4 w-4 cursor-pointer"
                          onClick={resetForm}
                        />
                      </div>
                      <FormControl>
                        <Textarea
                          placeholder="Enter a description for your image"
                          className="resize-none"
                          maxLength={TEXT_AREA_MAX_LENGTH}
                          disabled={genImgMutation.isLoading}
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        After you click, we will generate a image for you
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={genImgMutation.isLoading}>
                  {genImgMutation.isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Please wait...
                    </>
                  ) : (
                    <>
                      <SendIcon className="mr-2 h-4 w-4" />
                      Send
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </div>
          <div className="grid grid-cols-3 gap-4 p-6">
            {images.map((image) => (
              <ImageCard {...image} key={image.id} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
