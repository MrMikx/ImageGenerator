import { Inter } from "next/font/google";

import "@/web/styles/globals.css";

import { Metadata } from "next";
import { ClerkProvider } from "@clerk/nextjs";

import { appConfig } from "@/common/config";
import { Footer } from "@/web/components/footer";
import { Header } from "@/web/components/header";
import { RootProviders } from "@/web/core";
import { WithChildrenProps } from "@/web/ts";
import { cn } from "@/web/utils";
import { Toaster } from "@/web/components/ui/toaster";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: appConfig.title,
    template: `%s | ${appConfig.title}`
  }
};

export default async function RootLayout({
  children
}: WithChildrenProps): Promise<React.JSX.Element> {
  return (
    <ClerkProvider>
      <html lang="en">
        <head />
        <body
          className={cn(
            "min-h-screen bg-background font-sans antialiased",
            inter.className
          )}
        >
          <RootProviders>
            <div className="relative flex min-h-screen flex-col">
              <Header />
              <main className="flex-1">{children}</main>
              <Toaster />
              <Footer />
            </div>
          </RootProviders>
        </body>
      </html>
    </ClerkProvider>
  );
}
