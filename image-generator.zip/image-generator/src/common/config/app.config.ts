export const appConfig = {
  title: "Image Generator"
};
