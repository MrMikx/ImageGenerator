export type HttpRequestMethod =
  | "GET"
  | "POST"
  | "PUT"
  | "DELETE"
  | "PATCH"
  | "HEAD"
  | "OPTIONS"
  | "TRACE"
  | "CONNECT";

export type FetchRequestOptions = Omit<RequestInit, "body" | "method"> & {
  next?: {
    tags?: string[];
    revalidate?: number;
  };
};
