import { FetchRequestOptions, HttpRequestMethod } from "../ts";
import { HttpClient } from "./http.client";

export class FetchHttpClient extends HttpClient<FetchRequestOptions> {
  private static instance: FetchHttpClient;

  private constructor() {
    super();
  }

  public static getInstance(): FetchHttpClient {
    if (!FetchHttpClient.instance) {
      FetchHttpClient.instance = new FetchHttpClient();
    }
    return FetchHttpClient.instance;
  }

  protected async sendRequest<TResponse = unknown>(
    method: HttpRequestMethod,
    url: string,
    body: string | null,
    options?: FetchRequestOptions
  ): Promise<TResponse> {
    const requestOptions = this.mergeRequestOptions(options);

    const res = await fetch(url, {
      ...requestOptions,
      method,
      body
    }).then((response) => response.json());

    return res as TResponse;
  }
}
