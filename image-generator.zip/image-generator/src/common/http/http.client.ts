import { merge } from "lodash";

import { HttpRequestMethod } from "../ts";

export abstract class HttpClient<TRequestOptions = unknown> {
  private defaultRequestOptions: TRequestOptions = {} as TRequestOptions;

  protected abstract sendRequest<TResponse = unknown>(
    method: HttpRequestMethod,
    url: string,
    body: string | null,
    options?: TRequestOptions
  ): Promise<TResponse>;

  public get<T>(url: string, options?: TRequestOptions): Promise<T> {
    return this.sendRequest<T>("GET", url, null, options);
  }

  public post<T>(
    url: string,
    body: object,
    options?: TRequestOptions
  ): Promise<T> {
    return this.sendRequest<T>("POST", url, this.serializeBody(body), options);
  }

  public put<T>(
    url: string,
    body: object,
    options?: TRequestOptions
  ): Promise<T> {
    return this.sendRequest<T>("PUT", url, this.serializeBody(body), options);
  }

  public patch<T>(
    url: string,
    body: object,
    options?: TRequestOptions
  ): Promise<T> {
    return this.sendRequest<T>("PATCH", url, this.serializeBody(body), options);
  }

  public delete<T>(url: string, options?: TRequestOptions): Promise<T> {
    return this.sendRequest<T>("DELETE", url, null, options);
  }

  public sendNativeRequest<T>(
    url: string,
    method: HttpRequestMethod,
    body: string | null,
    options?: TRequestOptions
  ): Promise<T> {
    return this.sendRequest<T>(method, url, body, options);
  }

  protected mergeRequestOptions(options?: TRequestOptions): TRequestOptions {
    return merge({}, this.defaultRequestOptions, options);
  }

  protected setDefaultRequestOptions(options: TRequestOptions): void {
    this.defaultRequestOptions = options;
  }

  protected serializeBody(body: object | null): string | null {
    {
      if (!body) {
        return null;
      }
      return JSON.stringify(body);
    }
  }
}
