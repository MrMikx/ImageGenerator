import { FetchHttpClient } from "../http";
import { DeleteImageDto, GenerateImageDto, StoredImageDto } from "../models";

export class ImagesApiService {
  private constructor() {}

  private static readonly http = FetchHttpClient.getInstance();

  public static async sendGenerateImgRequest(dto: GenerateImageDto): Promise<{
    readonly status: "success" | "error";
  }> {
    const response = await this.http.post<{
      readonly status: "success" | "error";
    }>("/api/images/generate", dto);
    return response;
  }

  public static async getUserImages(): Promise<StoredImageDto[]> {
    return this.http.get<StoredImageDto[]>("/api/images");
  }

  public static async deleteImage(dto: DeleteImageDto): Promise<{
    readonly status: "success" | "error";
  }> {
    return this.http.delete<{
      readonly status: "success" | "error";
    }>(`/api/images/${dto.imageId}`);
  }
}
