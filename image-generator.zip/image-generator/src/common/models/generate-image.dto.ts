export interface GenerateImageDto {
  readonly text: string;
}
