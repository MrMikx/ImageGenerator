export * from "./delete-image.dto";
export * from "./generate-image.dto";
export * from "./stored.image.dto";
