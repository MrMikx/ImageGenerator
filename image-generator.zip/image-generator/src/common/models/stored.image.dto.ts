import { AnalyzedImage } from "@/api/models";

export interface StoredImageMetadata {
  readonly id: string;
  readonly userId: string;
  readonly categories: string;
  readonly description: string;
  readonly tags: string;
}

export interface StoredImageDto extends AnalyzedImage {
  readonly id: string;
  readonly imageUrl: string;
  readonly createdAt: string;
}
