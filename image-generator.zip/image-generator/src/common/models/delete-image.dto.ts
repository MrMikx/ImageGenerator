export interface DeleteImageDto {
  readonly imageId: string;
}
