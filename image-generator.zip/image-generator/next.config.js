/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["imagegeneratorimages.blob.core.windows.net"]
  }
};

module.exports = nextConfig;
